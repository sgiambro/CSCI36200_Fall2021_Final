To run this program you first have to compile the code by entering "make" into the command line. 
Then to run the code type "make run" into the command line as well.
once the code is running all you have to do is enter a word so the program can see if there is a match
if there is a mispelling the program will give a suggestion an all you have to do is say yes or no

********* THE PROGRAM ASSUMES THE FIRST LETTER IS NEVER MISSPELLED *********